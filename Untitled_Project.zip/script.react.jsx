import React, { useState } from 'react';

function App() {
  const [isDoorOpen, setIsDoorOpen] = useState(false);

  // Стили для контейнера (молочный фон)
  const containerStyle = {
    backgroundColor: '#F5F5DC', // Молочный цвет
    width: '100vw',
    height: '100vh',
    margin: 0,
    padding: 0,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  };

  // Стили для двери (больше человека)
  const doorStyle = {
    position: 'absolute',
    width: '200px', // Большая дверь
    height: '350px',
    backgroundColor: '#8B4513', // Коричневый
    bottom: '10%',
    left: '40%',
    transformOrigin: 'left center',
    transition: 'transform 1s ease',
    transform: isDoorOpen ? 'rotateY(90deg)' : 'rotateY(0deg)',
    border: '8px solid #5D4037', // Рамка
    borderRadius: '5px',
  };

  // Стили для человека
  const personStyle = {
    position: 'absolute',
    width: '60px', // Человек меньше двери
    height: '160px',
    backgroundColor: '#333',
    borderRadius: '10px',
    bottom: '10%',
    left: '65%',
  };

  // Стили для головы
  const headStyle = {
    position: 'absolute',
    width: '40px',
    height: '40px',
    backgroundColor: '#FFCC99',
    borderRadius: '50%',
    top: '-30px',
    left: '10px',
  };

  // Стили для руки (машет)
  const armRightStyle = {
    position: 'absolute',
    width: '10px',
    height: '60px',
    backgroundColor: '#333',
    top: '20px',
    right: '-10px',
    borderRadius: '5px',
    animation: 'wave 2s infinite alternate',
  };

  // Стили для левой руки
  const armLeftStyle = {
    position: 'absolute',
    width: '10px',
    height: '60px',
    backgroundColor: '#333',
    top: '20px',
    left: '-10px',
    borderRadius: '5px',
  };

  // Стили для ног
  const legRightStyle = {
    position: 'absolute',
    width: '12px',
    height: '50px',
    backgroundColor: '#333',
    bottom: '-50px',
    right: '15px',
    borderRadius: '5px',
  };

  const legLeftStyle = {
    position: 'absolute',
    width: '12px',
    height: '50px',
    backgroundColor: '#333',
    bottom: '-50px',
    left: '15px',
    borderRadius: '5px',
  };

  // Кнопки управления
  const buttonContainerStyle = {
    position: 'absolute',
    top: '20px',
    left: '50%',
    transform: 'translateX(-50%)',
    zIndex: 10,
  };

  const buttonStyle = {
    padding: '10px 20px',
    margin: '0 5px',
    cursor: 'pointer',
  };

  return (
    <div style={containerStyle}>
      <style>
        {`
          @keyframes wave {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(45deg); }
          }
        `}
      </style>
      
      <div style={buttonContainerStyle}>
        <button 
          style={buttonStyle}
          onClick={() => setIsDoorOpen(true)}
        >
          Открыть дверь
        </button>
        <button 
          style={buttonStyle}
          onClick={() => setIsDoorOpen(false)}
        >
          Закрыть дверь
        </button>
      </div>
      
      <div style={doorStyle}></div>
      
      <div style={personStyle}>
        <div style={headStyle}></div>
        <div style={armRightStyle}></div>
        <div style={armLeftStyle}></div>
        <div style={legRightStyle}></div>
        <div style={legLeftStyle}></div>
      </div>
    </div>
  );
}

export default App;